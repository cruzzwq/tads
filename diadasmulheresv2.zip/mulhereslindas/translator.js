async function translateText(text, targetLang) {
            const response = await fetch('https://libretranslate.de/translate', {
                method: 'POST',
                body: JSON.stringify({ q: text, source: 'auto', target: targetLang }),
                headers: { "Content-Type": "application/json" }
            });
            const data = await response.json();
            return data.translatedText;
        }

        document.getElementById("language").addEventListener("change", async function() {
            const lang = this.value;
            const elementsToTranslate = [
                { id: "title", text: "Bem-vindo ao nosso site" },
                { id: "description", text: "Este é um exemplo de tradutor integrado." }
            ];
            
            for (let element of elementsToTranslate) {
                const translatedText = await translateText(element.text, lang);
                document.getElementById(element.id).innerText = translatedText;
            }
        });