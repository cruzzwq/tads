function changeStyle(styleName) {
    document.getElementById('theme-style').setAttribute('href', styleName);
 }

