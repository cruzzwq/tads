const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);

app.use(express.static('public'));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/index.html');
});

io.on('connection', socket => {
  console.log('Usuário conectado:', socket.id);

  socket.on('join room', ({ username, room }) => {
    socket.join(room);
    console.log(`${username} entrou na sala ${room}`);
    socket.to(room).emit('user joined', { username, room });
  });

  socket.on('chat message', ({ username, room, message }) => {
    io.to(room).emit('chat message', { username, room, message });
  });

  socket.on('disconnect', () => {
    console.log('Usuário desconectado:', socket.id);
  });
});

const PORT = 3000;
http.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
