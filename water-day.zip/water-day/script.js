document.addEventListener('DOMContentLoaded', () => {
    const curiosidades = [
        
    ];

    const lista = document.getElementById('lista-curiosidades');
    curiosidades.forEach(c => {
        lista.innerHTML += `<li>${c}</li>`;
    });
});