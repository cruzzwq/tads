document.addEventListener("DOMContentLoaded", function () {
    const tabela = document.querySelector("#cartela tbody");
    const botaoSortear = document.getElementById("sortear");
    const numeroSorteadoEl = document.getElementById("numeroSorteado");

    let numerosSorteados = new Set();

    // Gera a cartela de 1 a 75 divididos entre as colunas B, I, N, G, O
    function gerarCartela() {
        let tabelaHtml = "";
        for (let i = 1; i <= 15; i++) {
            tabelaHtml += "<tr>";
            for (let j = 0; j < 5; j++) {
                let num = i + j * 15;
                tabelaHtml += `<td id="num${num}">${num}</td>`;
            }
            tabelaHtml += "</tr>";
        }
        tabela.innerHTML = tabelaHtml;
    }

    // Sorteia um número entre 1 e 75 e destaca na cartela
    function sortearNumero() {
        if (numerosSorteados.size === 75) {
            alert("Todos os números já foram sorteados!");
            return;
        }

        let numero;
        do {
            numero = Math.floor(Math.random() * 75) + 1;
        } while (numerosSorteados.has(numero));

        numerosSorteados.add(numero);

        let letra = obterLetra(numero);
        numeroSorteadoEl.textContent = `Número sorteado: ${letra}${numero}`;

        // Destacar número na cartela
        let celula = document.getElementById(`num${numero}`);
        if (celula) {
            celula.classList.add("sorteado");
        }
    }

    // Associa número à letra correta
    function obterLetra(numero) {
        if (numero <= 15) return "B";
        if (numero <= 30) return "I";
        if (numero <= 45) return "N";
        if (numero <= 60) return "G";
        return "O";
    }

    // Inicializa o jogo
    gerarCartela();
    botaoSortear.addEventListener("click", sortearNumero);
});
