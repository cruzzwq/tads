  const emojis = ['🐶', '🐱', '🦊', '🐼', '🐸', '🐷', '🐵', '🐯', '🐰', '🐻', '🐨', '🦁', '🐔', '🐙', '🦄', '🐧'];
        let cards = [];
        let flippedCards = [];
        let matchedCards = [];

        function startGame() {
            const board = document.getElementById('game-board');
            const winMessage = document.getElementById('win-message');
            board.innerHTML = '';
            winMessage.style.display = 'none';
            matchedCards = [];
            cards = [...emojis, ...emojis];
            cards.sort(() => Math.random() - 0.5);
            cards.forEach((emoji, index) => {
                const card = document.createElement('div');
                card.classList.add('card');
                card.dataset.index = index;
                card.dataset.emoji = emoji;
                card.addEventListener('click', flipCard);
                board.appendChild(card);
            });
        }

        function flipCard() {
            if (flippedCards.length < 2 && !this.classList.contains('flipped')) {
                this.textContent = this.dataset.emoji;
                this.classList.add('flipped');
                flippedCards.push(this);
            }
            
            if (flippedCards.length === 2) {
                setTimeout(checkMatch, 500);
            }
        }

        function checkMatch() {
            const [card1, card2] = flippedCards;
            if (card1.dataset.emoji === card2.dataset.emoji) {
                matchedCards.push(card1, card2);
            } else {
                card1.textContent = '';
                card2.textContent = '';
                card1.classList.remove('flipped');
                card2.classList.remove('flipped');
            }
            flippedCards = [];

            if (matchedCards.length === cards.length) {
                document.getElementById('win-message').style.display = 'block';
            }
        }

        startGame();