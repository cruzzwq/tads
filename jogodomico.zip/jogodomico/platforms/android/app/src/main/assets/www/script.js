let currentPlayer = 'X';
let board = ["", "", "", "", "", "", "", "", ""];
let moves = 0;
let gameOver = false;

// Recupera ou inicializa o ranking no localStorage
let ranking = JSON.parse(localStorage.getItem("ranking")) || { X: 0, O: 0 };

function chooseSymbol(symbol) {
    currentPlayer = symbol;
    document.getElementById("status").innerText = `Você escolheu: ${currentPlayer}`;
}

function createBoard() {
    const boardElement = document.getElementById("board");
    boardElement.innerHTML = "";
    board.forEach((_, index) => {
        const cell = document.createElement("div");
        cell.classList.add("cell");
        cell.setAttribute("data-index", index);
        cell.addEventListener("click", handleMove);
        boardElement.appendChild(cell);
    });
}

function handleMove(event) {
    if (gameOver) return;

    const index = event.target.getAttribute("data-index");
    if (board[index] !== "") return;

    board[index] = currentPlayer;
    event.target.innerText = currentPlayer;
    moves++;

    if (checkWin()) {
        document.getElementById("status").innerText = `${currentPlayer} venceu em ${moves} jogadas!`;
        updateRanking(currentPlayer);
        gameOver = true;
        return;
    }

    if (moves === 9) {
        document.getElementById("status").innerText = "Empate!";
        gameOver = true;
        return;
    }

    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
}

function checkWin() {
    const winPatterns = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],
        [0, 3, 6], [1, 4, 7], [2, 5, 8],
        [0, 4, 8], [2, 4, 6]
    ];
    return winPatterns.some(pattern => {
        const [a, b, c] = pattern;
        return board[a] && board[a] === board[b] && board[a] === board[c];
    });
}

function updateRanking(winner) {
    ranking[winner]++;
    localStorage.setItem("ranking", JSON.stringify(ranking));
    displayRanking();
}

function displayRanking() {
    document.getElementById("ranking").innerHTML = `
        <h3>Ranking</h3>
        <p>X: ${ranking.X} vitórias</p>
        <p>O: ${ranking.O} vitórias</p>
    `;
}

function resetGame() {
    board = ["", "", "", "", "", "", "", "", ""];
    moves = 0;
    gameOver = false;
    document.getElementById("status").innerText = "";
    createBoard();
}

function resetRanking() {
    ranking = { X: 0, O: 0 };
    localStorage.setItem("ranking", JSON.stringify(ranking));
    displayRanking();
}

document.addEventListener("DOMContentLoaded", () => {
    createBoard();
    displayRanking();
});
