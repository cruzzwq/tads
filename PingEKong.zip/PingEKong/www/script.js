// script.js
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const p1ScoreEl = document.getElementById("p1Score");
const p2ScoreEl = document.getElementById("p2Score");
const pauseBtn = document.getElementById("pauseBtn");
const menu = document.getElementById("menu");

const p1PowerSlots = [
  document.getElementById("p1Power1"),
  document.getElementById("p1Power2"),
];
const p2PowerSlots = [
  document.getElementById("p2Power1"),
  document.getElementById("p2Power2"),
];

let paddleWidth = 10,
  paddleHeight = 100,
  ballSize = 10;

let player1Y = 200,
  player2Y = 200;
let ballX = 400,
  ballY = 250;
let ballSpeedX = 5,
  ballSpeedY = 3;

let keys = {};
let isPaused = false;
let gameStarted = false;
let player1Score = 0,
  player2Score = 0;

let controlInvertedP1 = false;
let controlInvertedP2 = false;

const powerEmojis = {
  enlarge: "🔵",
  shrink: "🟣",
  fast: "💨",
  double: "✨",
  invert: "🔁",
};

let p1Powers = [];
let p2Powers = [];

document.addEventListener("keydown", (e) => {
  keys[e.key] = true;
  if (e.key === " ") togglePause();

  if (e.key.toLowerCase() === "q") activatePower(1, 0);
  if (e.key.toLowerCase() === "e") activatePower(1, 1);
  if (e.key === "ArrowLeft") activatePower(2, 0);
  if (e.key === "ArrowRight") activatePower(2, 1);
});

document.addEventListener("keyup", (e) => {
  keys[e.key] = false;
});

function startGame() {
  menu.style.display = "none";
  pauseBtn.style.display = "inline-block";
  gameStarted = true;
  setInterval(() => {
    giveRandomPower(1);
    giveRandomPower(2);
  }, 5000);
  requestAnimationFrame(gameLoop);
}

function togglePause() {
  if (!gameStarted) return;
  isPaused = !isPaused;
  pauseBtn.textContent = isPaused ? "Continuar (Espaço)" : "Pausar (Espaço)";
}

function update() {
  if (isPaused) return;

  const p1Up = controlInvertedP1 ? keys["s"] : keys["w"];
  const p1Down = controlInvertedP1 ? keys["w"] : keys["s"];
  const p2Up = controlInvertedP2 ? keys["ArrowDown"] : keys["ArrowUp"];
  const p2Down = controlInvertedP2 ? keys["ArrowUp"] : keys["ArrowDown"];

  if (p1Up && player1Y > 0) player1Y -= 6;
  if (p1Down && player1Y < canvas.height - paddleHeight) player1Y += 6;
  if (p2Up && player2Y > 0) player2Y -= 6;
  if (p2Down && player2Y < canvas.height - paddleHeight) player2Y += 6;

  ballX += ballSpeedX;
  ballY += ballSpeedY;

  if (ballY < 0 || ballY > canvas.height - ballSize) ballSpeedY *= -1;

  if (
    ballX < paddleWidth &&
    ballY > player1Y &&
    ballY < player1Y + paddleHeight
  ) ballSpeedX *= -1;

  if (
    ballX > canvas.width - paddleWidth - ballSize &&
    ballY > player2Y &&
    ballY < player2Y + paddleHeight
  ) ballSpeedX *= -1;

  if (ballX < 0) {
    player2Score++;
    updateScore();
    if (player2Score % 2 === 0) giveRandomPower(2);
    resetBall();
  }

  if (ballX > canvas.width) {
    player1Score++;
    updateScore();
    if (player1Score % 2 === 0) giveRandomPower(1);
    resetBall();
  }
}

function updateScore() {
  p1ScoreEl.textContent = player1Score;
  p2ScoreEl.textContent = player2Score;
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = "#555";
  for (let i = 0; i < canvas.height; i += 20)
    ctx.fillRect(canvas.width / 2 - 1, i, 2, 10);

  ctx.fillStyle = "#fff";
  ctx.fillRect(0, player1Y, paddleWidth, paddleHeight);
  ctx.fillRect(canvas.width - paddleWidth, player2Y, paddleWidth, paddleHeight);
  ctx.fillRect(ballX, ballY, ballSize, ballSize);
}

function resetBall() {
  ballX = canvas.width / 2;
  ballY = canvas.height / 2;
  ballSpeedX *= -1;
  ballSpeedY = Math.random() * 4 - 2 || 2;
}

function giveRandomPower(player) {
  const keys = Object.keys(powerEmojis);
  const selected = keys[Math.floor(Math.random() * keys.length)];

  if (player === 1 && p1Powers.length < 2) {
    p1Powers.push(selected);
    updatePowerSlots(1);
  } else if (player === 2 && p2Powers.length < 2) {
    p2Powers.push(selected);
    updatePowerSlots(2);
  }
}

function updatePowerSlots(player) {
  const powers = player === 1 ? p1Powers : p2Powers;
  const slots = player === 1 ? p1PowerSlots : p2PowerSlots;

  for (let i = 0; i < slots.length; i++) {
    slots[i].textContent = powers[i] ? powerEmojis[powers[i]] : "";
  }
}

function activatePower(player, slotIndex) {
  let powers = player === 1 ? p1Powers : p2Powers;
  if (!powers[slotIndex]) return;

  const power = powers[slotIndex];

  if (power === "enlarge") {
    ballSize = 20;
    setTimeout(() => (ballSize = 10), 5000);
  } else if (power === "shrink") {
    ballSize = 5;
    setTimeout(() => (ballSize = 10), 5000);
  } else if (power === "fast") {
    ballSpeedX *= 1.5;
    ballSpeedY *= 1.5;
    setTimeout(() => {
      ballSpeedX /= 1.5;
      ballSpeedY /= 1.5;
    }, 5000);
  } else if (power === "invert") {
    const target = player === 1 ? 2 : 1;
    if (target === 1) {
      controlInvertedP1 = true;
      setTimeout(() => (controlInvertedP1 = false), 5000);
    } else {
      controlInvertedP2 = true;
      setTimeout(() => (controlInvertedP2 = false), 5000);
    }
  }

  powers.splice(slotIndex, 1);
  updatePowerSlots(player);
}

function gameLoop() {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}
