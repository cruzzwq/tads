const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const scoreDisplay = document.getElementById("score");
const p1ScoreEl = document.getElementById("p1Score");
const p2ScoreEl = document.getElementById("p2Score");
const pauseBtn = document.getElementById("pauseBtn");

// Caixas dos poderes (devem existir no HTML)
const p1PowerSlots = [
  document.getElementById("p1Power1"),
  document.getElementById("p1Power2"),
];
const p2PowerSlots = [
  document.getElementById("p2Power1"),
  document.getElementById("p2Power2"),
];

let paddleWidth = 10,
  paddleHeight = 100,
  ballSize = 10;

let player1Y = 200,
  player2Y = 200;
let ballX = 400,
  ballY = 250;
let ballSpeedX = 5,
  ballSpeedY = 3;

let keys = {};
let isPaused = false;
let gameStarted = false;
let player1Score = 0,
  player2Score = 0;

// Poderes e emojis
const powerEmojis = {
  enlarge: "🔵", // bola maior
  shrink: "🟣", // bola menor
  fast: "💨", // bola mais rápida
  double: "✨", // pontuação dupla
  invert: "🔁", // inverter controles
};

// Armazena os poderes ganhos
let p1Powers = [];
let p2Powers = [];

// Flags para controle invertido
let player1InvertControls = false;
let player2InvertControls = false;

document.addEventListener("keydown", (e) => {
  keys[e.key] = true;

  if (e.key === " ") togglePause();

  // Ativação poderes Player 1 (Q e E)
  if (e.key.toLowerCase() === "q") activatePower(1, 0);
  if (e.key.toLowerCase() === "e") activatePower(1, 1);

  // Ativação poderes Player 2 (← e →)
  if (e.key === "ArrowLeft") activatePower(2, 0);
  if (e.key === "ArrowRight") activatePower(2, 1);
});

document.addEventListener("keyup", (e) => {
  keys[e.key] = false;
});

function startGame() {
  document.getElementById("menu").style.display = "none";
  pauseBtn.style.display = "inline-block";
  gameStarted = true;
  gameLoop();

  setInterval(() => {
    giveRandomPower(1);
    giveRandomPower(2);
  }, 10000);
  
}

function togglePause() {
  if (!gameStarted) return;
  isPaused = !isPaused;
  pauseBtn.textContent = isPaused ? "Continuar (Espaço)" : "Pausar (Espaço)";
}

function update() {
  if (isPaused) return;

  // Movimento dos jogadores - com controle invertido aplicado

  // Jogador 1 (W/S)
  if (!player1InvertControls) {
    if (keys["W"] && player1Y > 0) player1Y -= 6;
    if (keys["S"] && player1Y < canvas.height - paddleHeight) player1Y += 6;
  } else {
    // Invertido: W desce, S sobe
    if (keys["w"] && player1Y < canvas.height - paddleHeight) player1Y += 6;
    if (keys["s"] && player1Y > 0) player1Y -= 6;
  }

  // Jogador 2 (Setas cima/baixo)
  if (!player2InvertControls) {
    if (keys["ArrowUp"] && player2Y > 0) player2Y -= 6;
    if (keys["ArrowDown"] && player2Y < canvas.height - paddleHeight) player2Y += 6;
  } else {
    // Invertido: seta cima desce, seta baixo sobe
    if (keys["ArrowUp"] && player2Y < canvas.height - paddleHeight) player2Y += 6;
    if (keys["ArrowDown"] && player2Y > 0) player2Y -= 6;
  }

  // Bola
  ballX += ballSpeedX;
  ballY += ballSpeedY;

  // Colisão topo/fundo
  if (ballY < 0 || ballY > canvas.height - ballSize) {
    ballSpeedY *= -1;
  }

  // Colisão raquetes
  if (
    ballX < paddleWidth &&
    ballY > player1Y &&
    ballY < player1Y + paddleHeight
  ) {
    ballSpeedX *= -1;
  }

  if (
    ballX > canvas.width - paddleWidth - ballSize &&
    ballY > player2Y &&
    ballY < player2Y + paddleHeight
  ) {
    ballSpeedX *= -1;
  }

  // Pontuação e poderes
  if (ballX < 0) {
    player2Score++;
    updateScore();
    if (player2Score % 2 === 0) giveRandomPower(2);
    resetBall();
  }

  if (ballX > canvas.width) {
    player1Score++;
    updateScore();
    if (player1Score % 2 === 0) giveRandomPower(1);
    resetBall();
  }
}

function updateScore() {
  p1ScoreEl.textContent = player1Score;
  p2ScoreEl.textContent = player2Score;
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Linha central
  ctx.fillStyle = "#555";
  for (let i = 0; i < canvas.height; i += 20) {
    ctx.fillRect(canvas.width / 2 - 1, i, 2, 10);
  }

  // Raquetes
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, player1Y, paddleWidth, paddleHeight);
  ctx.fillRect(canvas.width - paddleWidth, player2Y, paddleWidth, paddleHeight);

  // Bola
  ctx.fillRect(ballX, ballY, ballSize, ballSize);
}

function resetBall() {
  ballX = canvas.width / 2;
  ballY = canvas.height / 2;
  ballSpeedX *= -1;
  ballSpeedY = Math.random() * 4 - 2 || 2;
}

// Função que sorteia e adiciona um poder ao jogador (máx 2 poderes)
function giveRandomPower(player) {
  const keys = Object.keys(powerEmojis);
  const selected = keys[Math.floor(Math.random() * keys.length)];

  if (player === 1) {
    if (p1Powers.length < 2) {
      p1Powers.push(selected);
      updatePowerSlots(1);
    }
  } else if (player === 2) {
    if (p2Powers.length < 2) {
      p2Powers.push(selected);
      updatePowerSlots(2);
    }
  }
}

// Atualiza os blocos de poderes na UI
function updatePowerSlots(player) {
  let powers = player === 1 ? p1Powers : p2Powers;
  let slots = player === 1 ? p1PowerSlots : p2PowerSlots;

  for (let i = 0; i < slots.length; i++) {
    slots[i].textContent = powers[i] ? powerEmojis[powers[i]] : "";
  }
}

// Ativação dos poderes ao pressionar as teclas correspondentes
function activatePower(player, slotIndex) {
  let powers = player === 1 ? p1Powers : p2Powers;

  if (!powers[slotIndex]) return; // não tem poder nesse slot

  let power = powers[slotIndex];

  console.log(`Jogador ${player} ativou o poder: ${power}`);

  if (power === "enlarge") {
    ballSize = 20;
    setTimeout(() => (ballSize = 10), 5000);
  } else if (power === "shrink") {
    ballSize = 5;
    setTimeout(() => (ballSize = 10), 5000);
  } else if (power === "fast") {
    ballSpeedX *= 1.5;
    ballSpeedY *= 1.5;
    setTimeout(() => {
      ballSpeedX /= 1.5;
      ballSpeedY /= 1.5;
    }, 5000);
  } else if (power === "double") {
    // Você pode implementar um flag para pontuação dupla, por exemplo
    doubleScoreActive[player] = true;
    setTimeout(() => {
      doubleScoreActive[player] = false;
    }, 5000);
  } else if (power === "invert") {
    if (player === 1) {
      player1InvertControls = true;
      setTimeout(() => (player1InvertControls = false), 5000);
    } else if (player === 2) {
      player2InvertControls = true;
      setTimeout(() => (player2InvertControls = false), 5000);
    }
  }

  // Remove o poder usado
  powers.splice(slotIndex, 1);
  updatePowerSlots(player);
}

// Flag para pontuação dupla (exemplo de uso)
let doubleScoreActive = {
  1: false,
  2: false,
};

// Atualize a pontuação para considerar o double score
function updateScore() {
  p1ScoreEl.textContent = player1Score;
  p2ScoreEl.textContent = player2Score;
}

// No lugar onde você incrementa a pontuação na função update:
function update() {
  if (isPaused) return;

  // Movimento dos jogadores - com controle invertido aplicado

  // Jogador 1 (W/S)
 if (!player1InvertControls) {
    if (keys["ArrowUp"] && player2Y > 0) player2Y -= 6;
    if (keys["ArrowDown"] && player2Y < canvas.height - paddleHeight) player2Y += 6;
  } else {
    // Invertido: seta cima desce, seta baixo sobe
    if (keys["ArrowUp"] && player2Y < canvas.height - paddleHeight) player2Y += 6;
    if (keys["ArrowDown"] && player2Y > 0) player2Y -= 6;
  }

  // Jogador 2 (Setas cima/baixo)
if (!player2InvertControls) {
    
  
  if (keys["W"] && player1Y > 0) player1Y -= 6;
    if (keys["S"] && player1Y < canvas.height - paddleHeight) player1Y += 6;
  } else {
    // Invertido: W desce, S sobe
    if (keys["W"] && player1Y < canvas.height - paddleHeight) player1Y += 6;
    if (keys["S"] && player1Y > 0) player1Y -= 6;
  }    
  // Bola
  ballX += ballSpeedX;
  ballY += ballSpeedY;

  // Colisão topo/fundo
  if (ballY < 0 || ballY > canvas.height - ballSize) {
    ballSpeedY *= -1;
  }

  // Colisão raquetes
  if (
    ballX < paddleWidth &&
    ballY > player1Y &&
    ballY < player1Y + paddleHeight
  ) {
    ballSpeedX *= -1;
  }

  if (
    ballX > canvas.width - paddleWidth - ballSize &&
    ballY > player2Y &&
    ballY < player2Y + paddleHeight
  ) {
    ballSpeedX *= -1;
  }

  // Pontuação e poderes
  if (ballX < 0) {
    player2Score += doubleScoreActive[2] ? 2 : 1;
    updateScore();
    if (player2Score % 2 === 0) giveRandomPower(2);
    resetBall();
  }

  if (ballX > canvas.width) {
    player1Score += doubleScoreActive[1] ? 2 : 1;
    updateScore();
    if (player1Score % 2 === 0) giveRandomPower(1);
    resetBall();
  }
}

function gameLoop() {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}
