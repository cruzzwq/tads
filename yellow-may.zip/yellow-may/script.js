const perguntas = [
  {
    pergunta: "Qual a cor do semáforo que indica PARE?",
    opcoes: ["Verde", "Amarelo", "Vermelho"],
    correta: 2
  },
  {
    pergunta: "É permitido usar o celular dirigindo?",
    opcoes: ["Sim", "Não", "Apenas no viva-voz"],
    correta: 1
  },
  {
    pergunta: "O que significa a faixa de pedestre?",
    opcoes: ["Lugar de estacionar", "Área de ultrapassagem", "Travessia segura para pedestres"],
    correta: 2
  },
  {
    pergunta: "Qual item de segurança é obrigatório para todos os ocupantes do veículo?",
    opcoes: ["Cinto de segurança", "Capacete", "Colete refletivo"],
    correta: 0
  },
  {
    pergunta: "Qual órgão coordena o trânsito no Brasil?",
    opcoes: ["DETRAN", "DENATRAN", "CONTRAN"],
    correta: 2
  }
];

function carregarQuiz() {
  const div = document.getElementById("perguntas");
  perguntas.forEach((q, i) => {
    const bloco = document.createElement("div");
    bloco.className = "pergunta";
    bloco.innerHTML = `
      <p><strong>${i + 1}. ${q.pergunta}</strong></p>
      ${q.opcoes.map((op, j) => `
        <label>
          <input type="radio" name="pergunta${i}" value="${j}">
          ${op}
        </label><br>`).join("")}
    `;
    div.appendChild(bloco);
  });
}

function verificarRespostas() {
  let acertos = 0;
  const resultado = document.getElementById("resultado");
  resultado.innerHTML = "";

  perguntas.forEach((q, i) => {
    const selecionada = document.querySelector(`input[name="pergunta${i}"]:checked`);
    const bloco = document.querySelectorAll(".pergunta")[i];

    if (selecionada) {
      const resposta = parseInt(selecionada.value);
      if (resposta === q.correta) {
        acertos++;
        bloco.innerHTML += `<p class="correta">✔ Resposta correta!</p>`;
      } else {
        bloco.innerHTML += `<p class="incorreta">✖ Errado! A resposta certa era: <strong>${q.opcoes[q.correta]}</strong></p>`;
      }
    } else {
      bloco.innerHTML += `<p class="incorreta">⚠ Você não respondeu esta pergunta.</p>`;
    }
  });

  resultado.innerHTML = `Você acertou <strong>${acertos}</strong> de ${perguntas.length} perguntas.`;
}

carregarQuiz();
