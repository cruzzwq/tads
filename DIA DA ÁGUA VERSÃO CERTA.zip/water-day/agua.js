let score = 0;
let time = 0;
let currentQuestionIndex = 0;
let timerInterval;

const questions = [
  {
    question: "Qual é a fórmula da água?",
    answers: [
      { text: "H₂O", correct: true },
      { text: "CO₂", correct: false },
      { text: "O₂", correct: false }
    ]
  },
  {
    question: "Qual porcentagem da Terra é coberta por água?",
    answers: [
      { text: "71%", correct: true },
      { text: "50%", correct: false },
      { text: "85%", correct: false }
    ]
  },
  {
    question: "O que é água potável?",
    answers: [
      { text: "Água própria para consumo", correct: true },
      { text: "Água salgada", correct: false },
      { text: "Água fervida", correct: false }
    ]
  },
  {
    question: "Qual é o maior oceano do mundo?",
    answers: [
      { text: "Oceano Pacífico", correct: true },
      { text: "Oceano Atlântico", correct: false },
      { text: "Oceano Índico", correct: false }
    ]
  },
  {
    question: "Qual é o pH da água pura?",
    answers: [
      { text: "7", correct: true },
      { text: "5", correct: false },
      { text: "9", correct: false }
    ]
  }
];

// Embaralhar respostas
function shuffleAnswers(answers) {
  for (let i = answers.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [answers[i], answers[j]] = [answers[j], answers[i]];
  }
}

// Iniciar o temporizador
function startTimer() {
  timerInterval = setInterval(() => {
    time++;
    document.getElementById("timer").innerText = `⏱ Tempo: ${time}s`;
  }, 1000);
}

// Parar o temporizador
function stopTimer() {
  clearInterval(timerInterval);
}

// Exibir a pergunta
function displayQuestion() {
  const quizDiv = document.getElementById("quiz");
  quizDiv.innerHTML = "";

  const questionData = questions[currentQuestionIndex];
  shuffleAnswers(questionData.answers);

  const questionElement = document.createElement("div");
  questionElement.classList.add("question");
  questionElement.innerText = questionData.question;
  quizDiv.appendChild(questionElement);

  questionData.answers.forEach(answer => {
    const button = document.createElement("button");
    button.classList.add("answer");
    button.innerText = answer.text;
    button.onclick = () => checkAnswer(button, answer.correct);
    quizDiv.appendChild(button);
  });
}

// Verificar resposta
function checkAnswer(button, isCorrect) {
  const allButtons = document.querySelectorAll(".answer");
  
  // Desativar todos os botões para evitar múltiplos cliques
  allButtons.forEach(btn => btn.disabled = true);

  if (isCorrect) {
    button.classList.add("correct");
    score++;
  } else {
    button.classList.add("wrong");
  }
  document.getElementById("score").innerText = `🌟 Pontuação: ${score}`;
  
  // Congelar tela por 3 segundos antes de passar para a próxima pergunta
  setTimeout(() => {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
      displayQuestion();
    } else {
      stopTimer();
      document.getElementById("quiz").innerHTML = `
        <div class="question">
          🚰 Quiz concluído! Sua pontuação final foi: <span style="color: #00ffcc;">${score}</span>
          <div>Você levou <span style="color: #ffcc00;">${time}s</span>.</div>
          <div style="margin-top: 20px;">
            <button onclick="window.location.reload()" style="
              padding: 10px 20px;
              font-size: 1.2em;
              color: #fff;
              background: #0066cc;
              border: none;
              border-radius: 15px;
              cursor: pointer;
              box-shadow: 0 5px 15px rgba(0,0,0,0.3);
              text-shadow: 1px 2px 4px #000;">🎉 Jogar novamente!</button>
          </div>
        </div>`;
    }
  }, 1000); // Congelar por 3 segundos (3000ms)
}

// Iniciar quiz
window.onload = () => {
  startTimer();
  displayQuestion();
};
